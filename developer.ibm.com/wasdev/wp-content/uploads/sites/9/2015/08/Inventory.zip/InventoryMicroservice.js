//Example POST method invocation
var Client = require('node-rest-client').Client;

var client = new Client();

// set content-type header and data as json in args parameter
var args = {
  data: { Name: "Anand",
          Address:"Austin",
          Age:"Nice-try !",
          SSN:"123",
        },
  headers:{"Content-Type": "application/json"}
};

// Store data in local DB
var JsonDB = require('node-json-db');
var db = new JsonDB("InventoryDataBase", true, false);
db.push("/Inventory",args);

// registering remote methods
client.registerMethod("getBillingInfo", "http://localhost:32768/BillingMicroservice/rest/Billing/microservice", "POST");

client.methods.getBillingInfo(args, function(data,response){
    // parsed response body as js object
  console.log(data);
    // raw response
  //console.log(response);
});
