// Create data-Store
var JsonDB = require('node-json-db');
try{
var db = new JsonDB("InventoryDB", true, false);
}catch(error){
console.log("db create error"+error);
}
